<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Our Personal Page</title>
    <link rel="stylesheet" type="text/css" href="Group 6.css">
</head>

<body>

    <header>
        <h1>Group 6</h1>
    </header>

    <h1 style="text-align: center;">Welcome to My Web Page</h1>

    <nav>
        <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="#message">Message</a></li>
        </ul>
    </nav>

    <section id="home">
        <h2>Welcome to Our Personal Website</h2>
        <p>Welcome to our very first website! This project is part of our major subject, Introduction to Web Technologies. We are BSIT-1B Group 6. It consists of a personal group website and a functional Registration Form. Our goal was to create a user-friendly interface that collects student data while maintaining a clean and responsive design. As you can see we used css code to make it pretty and this website was created as part of our learning journey in web development. Through this website, we practiced designing a simple and functional page using basic coding skills. It represents our effort, creativity, teamwork, and the knowledge we have gained while exploring how websites are built. We hope you enjoy viewing our work as much as we enjoyed creating it.</p>
    </section>

    <section id="about">
        <h2>About Us</h2>

        <!-- Jay -->
        <div>
            <p>Hi! My name is
                <a href="https://native-amaranth-ubx0vvvxxh.edgeone.app/Jay.jpg">
                    Jaylyn Danielle F. Sanchez
                </a>
                I'm 18yrs old and I'm turning 19 this August. One of my favorite hobbies is reading because I love getting lost in different stories, discovering new ideas, and learning from the experiences of the characters. I also enjoy crocheting. It helps me make creative items and have fun, like decorations, order because I sell my projects or gifts for my friends and family. In my free time, I listen to music using my phone and spend time with my friends or family. My goal is to finish my studies and have a better future.
            </p>
            <img src="https://native-amaranth-ubx0vvvxxh.edgeone.app/Jay.jpg" width="200">
            <h3>My Hobbies</h3>
            <ul>
                <li>Reading</li>
                <li>Coding</li>
                <li>Traveling</li>
            </ul>
        </div>

        <!-- Kharl-->
        <div>
            <p>Hi! My name is
                <a href="https://open-aqua-3hczwiwxbn.edgeone.app/Kharl.jpg">
                    Kharl Clifford S. Obanil
                </a>
                I'm 19 years old and I'm turning 20 this April. I'm the oldest of my siblings and I have a younger sister. I love playing different types of online games such as Roblox, Minecraft, and COD. Riding a bike with my friends helps me relax and have fun. Right now I'm obsessed with watching Warhammer because of their captivating storytelling not only by gameplay but also by the immersive narrative unfolding across different game editions.
            </p>
            <img src="https://open-aqua-3hczwiwxbn.edgeone.app/Kharl.jpg" width="200">
            <h3>My Hobbies</h3>
            <ul>
                <li>Biking</li>
                <li>Watching Warhammer</li>
                <li>Playing Online Games</li>
            </ul>
        </div>

        <!-- Jas -->
        <div>
            <p>Hi My name is
                <a href="https://lively-black-zaxaay8q9r.edgeone.app/Jas.jpg">
                    Jason M. Mina
                </a>
                I'm 19 years old and turning 20 this May. I love spending time with my family and friends. My goal is to make my parents proud and to graduate so that I can have a better life in the future.
            </p>
            <img src="https://lively-black-zaxaay8q9r.edgeone.app/Jas.jpg" width="200">
            <h3>My Hobbies</h3>
            <ul>
                <li>Coding</li>
                <li>Playing Online games</li>
                <li>Listening to music</li>
            </ul>
        </div>

        <!-- Eric -->
        <div>
            <p>Hi! My name is
                <a href="https://popular-salmon-xny1aunizj.edgeone.app/Eric.jpg">
                    John Eric Balasabas
                </a>
                I am 21 years old and turning 22 on October 19. I can say that I am a friendly type of person. I can get along with other people pretty easily. I really don't like people who lies and boastful. If you need a friend, just call my name and I'll be there.
            </p>
            <img src="https://popular-salmon-xny1aunizj.edgeone.app/Eric.jpg" width="200">
            <h3>My Hobbies</h3>
            <ul>
                <li>Basketball</li>
                <li>Playing Online games</li>
                <li>Listening to music</li>
            </ul>
        </div>

        <!-- Balaba  -->
        <div>
            <p>Hi! My name is
                <a href="https://comparable-white-uktriooubm.edgeone.app/Balaba.jpg">
                    John Balaba
                </a>
                I am 19 years old and turning 20 on August 12. And I like reading business books and also playing games. I'm a friendly guy and I can get along with other people easily.
            </p>
            <img src="https://comparable-white-uktriooubm.edgeone.app/Balaba.jpg" width="200">
            <h3>My Hobbies</h3>
            <ul>
                <li>Reading</li>
                <li>Playing Online games</li>
                <li>Singing</li>
            </ul>
        </div>

        <!-- Selwyn -->
        <div>
            <p>Hi! My name is
                <a href="https://crucial-blush-lyn3ejlutv.edgeone.app/Sel.jpg">
                    Selwyn Ralph Reyes
                </a>
                I am 18 years old. I like playing online games because they help me to relax. I also enjoy cooking because I like learning how to make different kinds of food.
            </p>
            <img src="https://crucial-blush-lyn3ejlutv.edgeone.app/Sel.jpg" width="200">
            <h3>My Hobbies</h3>
            <ul>
                <li>Playing Online games</li>
                <li>Basketball</li>
                <li>Cooking</li>
            </ul>
        </div>

    </section>
    
    <section id="contact">
      <h3>If you have suggestions about our page, please contact any of the followings:</h3>
            <ul>
                <li>jmmina@paterostechnologicalcollege.edu.ph</li>
                <li>jfsanchez@paterostechnologicalcollege.edu.ph</li>
                <li>jerbalasabas@paterostechnologicalcollege.edu.ph</li>
                <li>spreyes@paterostechnologicalcollege.edu.ph</li>
                <li>jbalaba@paterostechnologicalcollege.edu.ph</li>
                <li>ksobanil@paterostechnologicalcollege.edu.ph</li>
            </ul>
      
    </section>

    <section id="message">
<section id="message">

<?php
if(isset($_GET['name']) && isset($_GET['message'])) {

    $name = htmlspecialchars($_GET['name']);
    $message = htmlspecialchars($_GET['message']);

    echo "<h3>Thank You for your Message! $name</h3>";

    echo "Name: $name <br>";
    echo "Message: $message";

} 

else {
?>
<h3>Leave Us a Message!!^^</h3>

<form method="GET" action="">
    Name:
    <input type="text" name="name" required>
    <br><br>

    Message:
    <input type="text" name="message" required>
    <br><br>

    <input type="submit" value="GET Submit"> 
</form> 

<?php
}
?>

</section>

    </section>

    <footer>
        <p>&copy; 2026 GROUP 6 BSIT-1B All rights reserved.</p>
    </footer>

</body>

</html>